#ifndef _AP2_BUFFERED_AUDIO_PROCESSOR_H
#define _AP2_BUFFERED_AUDIO_PROCESSOR_H

void *rtp_buffered_audio_processor(void *arg);

#endif // _AP2_BUFFERED_AUDIO_PROCESSOR_H
