#ifndef _AP2_EVENT_RECEIVER_H
#define _AP2_EVENT_RECEIVER_H

void *ap2_event_receiver(void *arg);

#endif // _AP2_EVENT_RECEIVER_H
