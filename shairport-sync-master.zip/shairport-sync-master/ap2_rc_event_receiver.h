// RC means Remote Control

#ifndef _AP2_RC_EVENT_RECEIVER_H
#define _AP2_RC_EVENT_RECEIVER_H

void *ap2_rc_event_receiver(void *arg);

#endif // _AP2_RC_EVENT_RECEIVER_H
