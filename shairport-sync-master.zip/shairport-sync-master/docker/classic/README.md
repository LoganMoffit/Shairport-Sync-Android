# Classic (aka AirPlay 1 Only) Docker Image

See the [Shairport Sync Docker Hub Repo](https://hub.docker.com/r/mikebrady/shairport-sync) for available tags.