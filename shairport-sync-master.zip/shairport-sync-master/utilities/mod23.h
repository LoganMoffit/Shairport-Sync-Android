#ifndef _MOD23_H
#define _MOD23_H

int32_t a_minus_b_mod23(uint32_t a, uint32_t b);

#endif // _MOD23_H
